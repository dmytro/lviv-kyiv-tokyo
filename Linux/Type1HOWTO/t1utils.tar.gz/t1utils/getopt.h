/* getopt.h - get command line options
 *
 * Parse the command line options, System V style.
*/

int getopt(int, char *[], char *);
