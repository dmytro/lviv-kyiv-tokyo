/*
 * Copyright (c) 1998
 *  Sergey A. Babkin.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * A simple program to draw the Bezier curves on alphanumeric display.
 *
 * Sergey A. Babkin (sab123@hotmail.com, babkin@bellatlantic.net)
 *
 */


#include <stdio.h>
#include <stdlib.h>

#define MAXX	980
#define MAXY	310
#define MAXN	(4*MAXX)

int screen[MAXY][MAXX];
double dots[MAXN][2];

main(argc,argv)
	int argc;
	char **argv;
{
	double scale;

	scale=(double)MAXX/(double)MAXY*240.0/320.0;

	cleanscreen();

	/*
	drawcurve('#', 0,0, 51,0, 1,49, 45,98);
	drawcurve('1', 5,28, 8,37, 16,65, 45,98);

	drawcurve('3', 0,0, 0,24, 30,68, 80,72);

	drawcurve('1', 0,0, 0,5, 1,10, 2,15);
	drawcurve('2', 2,15, 8,42, 30,68, 80,72);

	drawcurve('4', 0,0, 0,37, 22,67, 80,72);
	*/

	drawcurve('#', 0,0, 300,0,  300,300, 300,300);
	drawcurve('*', 0,0, 0,0,  300,0, 300,300);

	printscreen();
}

sumcurves(dx11, dy11, dx12, dy12, dx13, dy13,
	dx21, dy21, dx22, dy22, dx23, dy23)
{
}

cleanscreen()
{
	int i,j;

	for(i=0; i<MAXY; i++)
		for(j=0; j<MAXX; j++)
			screen[i][j]=' ';
}

drawcurve(mark, ax,ay, bx,by, cx,cy, dx,dy)
	int mark, ax,ay, bx,by, cx,cy, dx,dy;
{
	int i,j,n,c;
	double scale;

	scale=(double)MAXX/(double)MAXY*240.0/320.0;

	for(i=0; i<MAXN; i++) {
		double t;

		t=(double)i/(double)(MAXN-1);
		dots[i][0]=ax*t*t*t+bx*3*t*t*(1-t)+cx*3*t*(1-t)*(1-t)+
			dx*(1-t)*(1-t)*(1-t);
		dots[i][1]=ay*t*t*t+by*3*t*t*(1-t)+cy*3*t*(1-t)*(1-t)+
			dy*(1-t)*(1-t)*(1-t);
	}
	n=MAXN;
	
	for(i=0; i<n; i++)
		if(dots[i][0]>=0 && dots[i][0]<MAXX
		&& dots[i][1]>=0 && dots[i][1]<MAXY)
			screen[(int)(dots[i][1]+0.5)][(int)(dots[i][0]*scale+0.5)]=mark;

}

printscreen()
{
	int i,j;

	for(i=0; i<MAXY; i++) {
		for(j=0; j<MAXX; j++)
			putchar(screen[i][j]);
		putchar('\n');
	}
		
}
